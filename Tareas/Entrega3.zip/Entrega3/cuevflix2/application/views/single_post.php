<div class="otherPost well">
  <div class="otherAvatar">
    <img src="../../assets/img/avatars/assassin_avatar.png"
         alt=""
         data-title="&lt;span class='badge badge-info'&gt;12&lt;/span&gt; Rodrigo Lopez"
         data-content=10>
  </div>
  <div class="otherPostInfo">
    <div class="otherPostBody"><p><?php echo $body ?></p></div>
    <hr/>
    <div class="otherPostDate"><p class="pull-right"><?php echo $createdDate ?></p></div>
  </div>
</div>