<?php $this->load->view('header') ?>
hola